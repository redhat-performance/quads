<?php

if ( ! class_exists( 'MarkdownExtra_Parser' ) )
	require_once('extra.php');

require_once('gfm.php');